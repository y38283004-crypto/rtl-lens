RTL Lens offline demo

Extract this ZIP, then open width-warning.html or width-fixed.html in a browser.
No server or network connection is required to view the reports.

width-warning: 1 width-truncation warning.
width-fixed:   0 current findings after explicit low-four-bit selection.
Both are complete, redacted PySlang-only scans of synthetic two-module RTL.
The reports retain the actual engine version, timestamp and duration.

Reproduce from source: https://github.com/y38283004-crypto/rtl-lens/tree/main/examples/width-demo
Reports are static diagnostic observations, not functional verification.

简体中文：解压后双击 HTML 即可查看。问题示例有 1 个位宽告警，修复示例当前诊断数为零。
